Jeu du Serpent/Snake Game-------------------------
Url     : http://codes-sources.commentcamarche.net/source/103538-jeu-du-serpent-snake-gameAuteur  : Lane_R6Date    : 24/06/2022
Licence :
=========

Ce document intitul� � Jeu du Serpent/Snake Game � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Snake Game  (Juste pour s'amuser)
<br />
<br />♣ Ce Projet est un simple de 
jeu de serpent en javascript utilisant la balise canvas.
<br />♣ Le jeu inclu
t du son lorsque le serpent consomme un fruit.
<br />♣ La vitesse du serpent 
augmente lorsqu'il mange 6 fruit.
<br />♣ Le temps d'une partie peut être é
valué.
<br />♣ Possibilité de rejouer et de mettre pause.
<br />♣ Possib
ilité de visualiser le score du joeur.
<br />♣ Les Fruits apparaîssent de f
açon aléatoire sur la grille.
<br />♣ L'interface est très conviviale, de 
préférence sur le Navigateur Google Chrome.
