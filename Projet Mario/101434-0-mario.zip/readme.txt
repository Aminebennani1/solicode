Mario !-------
Url     : http://codes-sources.commentcamarche.net/source/101434-marioAuteur  : samsamdu44Date    : 03/01/2023
Licence :
=========

Ce document intitul� � Mario ! � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Bonjour, petit jeu de plateforme se jouant avec les flèches directionnelles du 
clavier.
<br />Dans ma version il n'y a pas de monstres mais des pics.
